<label class="font-bold mb-2 block text-gray-500">{{$text}}</label>

@props(['text'])
