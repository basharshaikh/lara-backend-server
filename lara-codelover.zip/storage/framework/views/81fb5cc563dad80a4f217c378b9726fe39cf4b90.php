<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('All Products')); ?><br> <small class="text-slate-500">Product list | livewire</small>
        </h2>
     <?php $__env->endSlot(); ?>

    <div>
        <div class="grid grid-cols-1 lg:grid-cols-4 gap-5 sm:grid-cols-1 md:grid-cols-4 justify-items-stretch border-b mb-3">
            <div>
                <input type="text" wire:model="search" name="search" class="vbc-input-field" placeholder="Search product"/>
            </div>

            <div class="hidden lg:block"></div>
            <div class="hidden lg:block"></div>

            <div class="justify-self-end">
                <a href="/add-product"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.partials.button','data' => ['type' => 'button','text' => 'Add New']]); ?>
<?php $component->withName('partials.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'button','text' => 'Add New']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></a>
            </div>
        </div>

        <div wire:loading>
            Loading...
        </div>
        <?php if(count($products)): ?>
        <div wire:loading.remove>
            <div class="grid grid-cols-1 lg:grid-cols-4 gap-5 sm:grid-cols-1 md:grid-cols-2">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="project-item bg-[#FEFFE1] rounded-sm overflow-hidden">
                    
                    <div class="project-img relative">
                        <div class="preview-img h-[188px] bg-[#333]"></div> 
                    </div>
                    
                    <div class="project-cont p-4">
                        <h3 class="mb-2 font-bold text-lg relative"><?php echo e($product->title); ?></h3>
                        <p class="text-sm"><?php echo e($product->excerpt); ?></p>
                    </div>

                    <div class="border-t border-[#f1f1f1] flex justify-between p-2">
                        <a href="/product/<?php echo e($product->id); ?>/edit"><?php echo $__env->make('partials.icons.linkOpen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>
                        <span onClick="confirm('Are you sure?')" wire:click="deleteProduct(<?php echo e($product->id); ?>)" class="cursor-pointer"><?php echo $__env->make('partials.icons.deleteIcon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-4"><?php echo e($products); ?></div>
            </div>  
        </div>
        
        <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.partials.emptyAlert','data' => []]); ?>
<?php $component->withName('partials.emptyAlert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <p>No product found!</p>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.partials.alert','data' => []]); ?>
<?php $component->withName('partials.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div><?php /**PATH E:\Travarsy-Media\own codelover\lara-codelover\resources\views/livewire/product/all-products.blade.php ENDPATH**/ ?>