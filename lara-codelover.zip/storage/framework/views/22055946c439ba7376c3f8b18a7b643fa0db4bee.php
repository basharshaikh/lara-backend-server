<small style="background-color: <?php echo e($color); ?>" class="text-white py-[2px] px-2 rounded inline-block mr-1 mt-[5px]"><?php echo e($text); ?></small>

<?php $attributes = $attributes->exceptProps([
    'text',
    'color'
]); ?>
<?php foreach (array_filter(([
    'text',
    'color'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php /**PATH E:\Travarsy-Media\own codelover\lara-codelover\resources\views/components/partials/pill.blade.php ENDPATH**/ ?>