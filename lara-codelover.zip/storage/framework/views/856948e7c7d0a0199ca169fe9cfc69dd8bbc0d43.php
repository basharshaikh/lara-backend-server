<label class="font-bold mb-2 block text-gray-500"><?php echo e($text); ?></label>

<?php $attributes = $attributes->exceptProps(['text']); ?>
<?php foreach (array_filter((['text']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php /**PATH E:\Travarsy-Media\own codelover\lara-codelover\resources\views/components/partials/field-label.blade.php ENDPATH**/ ?>