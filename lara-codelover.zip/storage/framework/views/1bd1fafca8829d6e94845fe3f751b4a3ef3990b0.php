<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight inline-block">
            <?php echo e(__('Projects')); ?> 
        </h2><small> Project list | blade</small>
     <?php $__env->endSlot(); ?>

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-5 sm:grid-cols-1 md:grid-cols-2">       
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="project-item bg-[#FEFFE1] rounded-sm overflow-hidden">
            
            <div class="project-img relative">
                <?php if($project->label): ?>
                    <small class="bg-[#f71c4b] text-white py-[2px] px-2 rounded inline-block mr-1 mt-[5px] absolute top-1 right-1"><?php echo e($project->label); ?></small>
                <?php endif; ?>
                <?php if($project->featured_image): ?>
                    <img src="<?php echo e(featured_img_url($project->featured_image)); ?>" alt="">
                <?php else: ?>
                    <div class="preview-img h-[188px] bg-[#333]"></div>
                <?php endif; ?>
            </div>
            
            <div class="project-cont p-4">
                <h3 class="mb-2 font-bold text-lg relative"><?php echo e($project->title); ?></h3>
                <p class="text-sm"><?php echo e($project->excerpt); ?></p>
            </div>

            <div class="border-t border-[#f1f1f1] flex justify-between p-2">
                <a href="/projects/<?php echo e($project->id); ?>/edit"><?php echo $__env->make('partials.icons.linkOpen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>
                <?php echo $__env->make('partials.icons.deleteIcon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH E:\Travarsy-Media\own codelover\lara-codelover\resources\views/projects.blade.php ENDPATH**/ ?>