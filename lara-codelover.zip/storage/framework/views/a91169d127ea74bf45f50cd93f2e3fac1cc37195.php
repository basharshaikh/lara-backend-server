 <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight inline-block">
        <?php echo e(__('Products')); ?>

    </h2><small> Product list.</small>
 <?php $__env->endSlot(); ?>

<div>
    <h2>This live</h2>
</div><?php /**PATH E:\Travarsy-Media\own codelover\lara-codelover\resources\views/livewire/products.blade.php ENDPATH**/ ?>