<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight inline-block">
            <?php echo e(__('Projects')); ?> 
        </h2><br><small> Edit project | blade</small>
     <?php $__env->endSlot(); ?>

    <form class="space-y-6" action="/projects/<?php echo e($project->id); ?>/edit" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="grid grid-cols-1 lg:grid-cols-10 gap-4 sm:grid-cols-1 md:grid-cols-1">
        <div class="col-span-7">
            <div class="flex mb-4">
            <h3 class="font-bold text-xl w-[50%]">Add new project</h3>
            </div>

            <!-- Left full section -->
            <div class=" -space-y-px">
                <div>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.partials.field-label','data' => ['text' => 'Project title']]); ?>
<?php $component->withName('partials.field-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Project title']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" name="title" value="<?php echo e($project->title); ?>" class="vbc-input-field" placeholder="Project title" />
                </div>

                <div class="pt-3">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.partials.field-label','data' => ['text' => 'Project Description']]); ?>
<?php $component->withName('partials.field-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Project Description']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <input type="hidden" name="description">
                    <div id="editor" style="height: 200px">
                        
                    </div>
                </div>

                <div class="pt-3">              
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.partials.field-label','data' => ['text' => 'Project Excerpt']]); ?>
<?php $component->withName('partials.field-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Project Excerpt']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <textarea name="excerpt" cols="30" rows="10" class="vbc-input-field" placeholder="Project excerpt"><?php echo e($project->excerpt); ?></textarea>
                </div>

                <div  class="pt-3">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.partials.field-label','data' => ['text' => 'Project Label']]); ?>
<?php $component->withName('partials.field-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Project Label']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <input type="text" name="label" value="<?php echo e($project->label); ?>" class="vbc-input-field" placeholder="Project label" />
                </div>
            </div>
        </div>

        <!-- Right sidebar -->
        <div class="col-span-7 lg:col-span-3">
            <div class="publish-box border-[1px] mb-4">
                <h4 class="text-lg font-bold border-b-[1px] py-2 px-3">Publish</h4>
                <div class="p-3">
                    You can save as draft or publish it publicly. also delete it from here.
                </div>
                <div class="p-3">
                    <div class="w-[60%] inline-block">
                        <div class="inline-block">
                            <select name="status" class="vbc-input-field !pr-8">
                                <option <?php echo e(($project->status == 'publish') ? 'selected' : ''); ?> value="publish">Publish</option>
                                <option <?php echo e(($project->status == 'draft') ? 'selected' : ''); ?> value="draft">Draft</option>
                            </select>
                        </div>

                        <div class="inline-block">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.partials.button','data' => ['type' => 'submit','text' => 'Save']]); ?>
<?php $component->withName('partials.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit','text' => 'Save']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div x-data="{ingredients: <?php echo e($project->ingredients); ?>}" class="publish-box border-[1px] mb-4">    
                
                <h4 class="text-lg font-bold border-b-[1px] py-2 px-3">Project ingredients</h4>
                <div class="p-3" x-init="console.log()">
                    You can add multiple items from here.
                </div>
                <input type="hidden" name="ingredients" x-model="JSON.stringify(ingredients)">
                <div class="px-3">
                    <div class="w-full text-right mb-2">
                        <button @click="ingredients.splice(0, 0, {id: uuidv4(), text: 'Laravel', color: '#333'})" type="button" class="text-white bg-indigo-500 p-1 px-3 border rounded-sm cursor-pointer">+ Add</button>
                    </div>
                    <div class="mb-4">
                        <hr>
                        <template x-for="ingredient in ingredients">
                            <small :style="`background-color: ${ingredient.color}`" class="text-white py-[2px] px-2 rounded inline-block mr-1 mt-[5px]" x-text="ingredient.text"></small>
                        </template>
                    </div>

                    <template x-for="(ingredient, index) in ingredients">
                    <div class="flex">
                        <input x-model="ingredient.color" type="text" class="vbc-input-field w-[85px]" :style="`background: ${ingredient.color}`">
                        <input x-model="ingredient.text" :id="ingredient.id" type="text" class="vbc-input-field" placeholder="ingredient" :value="ingredient.text"/>

                        <!-- add ingre -->
                        <button @click="ingredients.splice(index, 0, {id: uuidv4(), text: 'Laravel', color: '#333'})" type="button" class="bg-blue-900 p-2 px-3 inline-block h-[39px] relative -top-[1px] border rounded-sm cursor-pointer">
                            <div class="text-white">
                                <?php echo $__env->make('partials.icons.plusIcon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </button>
                        <!-- delete ingre -->
                        <button @click="ingredients.splice(index, 1)" type="button" class="bg-red-500 p-2 inline-block h-[39px] relative -top-[1px] border rounded-sm cursor-pointer">
                            <div class="text-white">
                                <?php echo $__env->make('partials.icons.trashIcon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </button>
                    </div>
                    </template>
                
                </div>
            </div>

            <div class="publish-box border-[1px]">
                <h4 class="text-lg font-bold border-b-[1px] py-2 px-3">Featured Image</h4>
                <div class="p-3">
                    You can choose an image from media as this project featured image.
                </div>

                <div class="px-3">
                    <input type="hidden" name="mediaID" value="<?php echo e($project->featured_image); ?>">
                    <img src="<?php echo e(featured_img_url($project->featured_image)); ?>" class="mb-3"/>
                </div>
                
                <div class="p-3 text-right">
                
                </div>
            </div>
            </div>
        </div>
        
    </form>

<script src="//cdn.quilljs.com/1.3.6/quill.min.js"></script>
<script>
    var editor = new Quill('#editor', {
        theme: 'snow',
    });

    editor.setContents(<?php echo $project->description ?>)
    var description = document.querySelector('input[name=description]');
    description.value = JSON.stringify(<?php echo $project->description ?>)

    editor.on('text-change', function(delta, oldDelta, source) {
        console.log(editor.getContents())
        description.value = JSON.stringify(editor.getContents())
    });
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH E:\Travarsy-Media\own codelover\lara-codelover\resources\views/group/project/edit.blade.php ENDPATH**/ ?>