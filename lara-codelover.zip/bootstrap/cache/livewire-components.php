<?php return array (
  'product.add-product' => 'App\\Http\\Livewire\\Product\\AddProduct',
  'product.all-product' => 'App\\Http\\Livewire\\Product\\AllProduct',
  'product.all-products' => 'App\\Http\\Livewire\\Product\\AllProducts',
);